# Styling
All icons used were taken from [Bootstrap Icons](https://icons.getbootstrap.com/).

Styling for text input boxes, popups, and overlays inspired by [w3schools](https://www.w3schools.com/css/default.asp).



